import 'package:flutter/material.dart';
import 'package:flutter_gerente_loja/screens/login/widgets/form_container.dart';

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black38,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Container(
            height: 200,
            child: Icon(
              Icons.local_convenience_store,
              color: Theme.of(context).primaryColor,
            ),
          ),
          FormContainer(),
          Container(
            height: 30,
            child: RaisedButton(
              onPressed: () {},
              child: Text(
                "Entrar"
              ),
            ),
          )
        ],
      ),
    );
  }
}
